import hello_func
from hello_func import helloworld

p=helloworld()
print(p)